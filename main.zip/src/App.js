import React from "react";
import Header from "./Header";
import Search from "../src/Components/SearchBar"
import "./App.css";
import BookData from "./Data.json"


function App() {
  return (
    <div className="App">
      <Header/>
      <Search placeholder="請輸入書名..." data={BookData}/>
    </div>
  );
}

export default App;
